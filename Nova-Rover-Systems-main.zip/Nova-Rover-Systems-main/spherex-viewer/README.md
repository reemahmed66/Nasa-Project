# 🌌 Planet X and SPHEREx: A Time Machine for the Infrared Sky

> **NASA Space Apps Challenge (Cairo 2026 — 12th Edition)**  
> **Team Name:** Nova Rover Systems  

---

## 🚀 Overview
**Planet X and SPHEREx** is a cutting-edge, dual-interface astronomical exploration platform designed to democratize access to NASA's massive multi-epoch infrared archives[cite: 1, 2, 3]. Our web application bridges the gap between complex space telescope data and interactive citizen science, allowing users to time-travel across the infrared cosmos, isolate transient cosmic objects, and inspect spectral signatures in real-time.

---

## ✨ Key Features & Scientific Highlights

1. **Cinematic 3D Landing & Storytelling (`index.html`):**
   - Immersive space narrative powered by **Three.js**, **GSAP**, and **Lenis** smooth scrolling[cite: 1, 2].
   - Compares legacy missions (Euclid, WISE, NEOWISE) with NASA's flagship **SPHEREx** observatory[cite: 1, 2].

2. **Advanced Sky Explorer Dashboard (`explorer.html`):**
   - **Spatial Query & Sky Zoning:** Optimized celestial partitioning to query coordinates (Right Ascension & Declination) or instant preset targets (Andromeda, Crab Nebula, Orion Nebula, Galactic Center) without latency[cite: 3].
   - **Single vs. Difference Mode:** 
     - *Single Mode:* Inspects direct observational frames at specific epochs to study static sky brightness.
     - *Difference Mode:* Subtracts background means across epochs to instantly isolate fast-moving asteroids, comets, or variable transient sources.
   - **Automated Guided Tour:** Automatically triggers an interactive, user-friendly step-by-step walkthrough upon entering the explorer dashboard.
   - **Spectral Band Analysis:** Visualizes 102 infrared spectral bands across detectors (D1 to D6) to inspect fluxes and wavelengths.

---

## 🛠️ Tech Stack & Architecture

- **Frontend Core:** HTML5, Tailwind CSS, JavaScript (ES6+)[cite: 1, 2, 3]
- **3D & Animation Graphics:** Three.js, GSAP (GreenSock Animation Platform), ScrollTrigger, Lenis[cite: 1, 2]
- **Data Processing & Backend Utilities:** Python (pandas, openpyxl, WeasyPrint) for background roster processing and data pipelining.
- **Performance Optimization:** Spatial indexing / Sky Zoning for instant client-side rendering of pre-tested target patches.

---

## 📂 Project Structure

```tree
spherex-viewer/
├── index.html          # Cinematic 3D landing & story page
├── explorer.html       # Interactive sky viewer & time-series dashboard
├── style.css           # Custom astronomical UI styles & animations
├── story.js            # Scroll & 3D cinematic triggers
├── explorer.js         # Sky rendering, frame loops, & tour logic
├── app/                # Python backend processing scripts
└── tests/              # API and pipeline validation tests names (`t_min`, `access_url`).
- Which FLAGS bits to mask (currently any non-zero flag when "Hide flagged pixels" is on).
