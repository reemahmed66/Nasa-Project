(()=>{
const ROOT=document.getElementById('xp'),$=s=>document.querySelector(s),API=location.protocol==='file:'?'http://localhost:8000':'',PI=Math.PI;

/* ============ 3D SCENE ============ */
const renderer=new THREE.WebGLRenderer({canvas:$('#xgl'),antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(60,1,.1,6000);
scene.add(camera); // needed so the warp streaks (camera children) render
function resize(){renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix()}
addEventListener('resize',resize);resize();

const D3=new THREE.Vector3(),V=new THREE.Vector3(),Y=new THREE.Vector3(0,1,0);
const dirYP=(y,p)=>D3.set(Math.sin(y)*Math.cos(p),Math.sin(p),-Math.cos(y)*Math.cos(p));
const at=(d,y,p)=>dirYP(y*PI/180,p*PI/180).clone().multiplyScalar(d);
const radec=(ra,dec)=>{const a=ra*PI/180,d=dec*PI/180;return new THREE.Vector3(Math.cos(d)*Math.cos(a),Math.sin(d),-Math.cos(d)*Math.sin(a))};
const glowTex=(()=>{const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d'),r=g.createRadialGradient(32,32,0,32,32,32);
  r.addColorStop(0,'#fff');r.addColorStop(.25,'rgba(255,255,255,.6)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,64,64);return new THREE.CanvasTexture(c)})();
const add=(o)=>{scene.add(o);return o},spin=[],gal=[];
const pts=(p,c,size,att)=>{const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(p,3));g.setAttribute('color',new THREE.BufferAttribute(c,3));
  return new THREE.Points(g,new THREE.PointsMaterial({size,map:glowTex,vertexColors:true,sizeAttenuation:att,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending}))};

// Stars: 9000 points in a big sphere around the origin
(()=>{const n=9000,p=new Float32Array(n*3),c=new Float32Array(n*3),k=new THREE.Color();
  for(let i=0;i<n;i++){const u=Math.random()*2-1,th=Math.random()*2*PI,s=Math.sqrt(1-u*u),r=120+Math.pow(Math.random(),.7)*2800;
    p.set([s*Math.cos(th)*r,u*r,s*Math.sin(th)*r],i*3);k.setHSL(Math.random()<.7?.6:.08,.5,.6+Math.random()*.4);c.set([k.r,k.g,k.b],i*3)}
  add(pts(p,c,2.2,false))})();

// Spiral galaxies: log-spiral arms + gaussian scatter, colour fades core -> rim
function galaxy(pos,R,c1,c2,tilt){const n=9000,p=new Float32Array(n*3),c=new Float32Array(n*3),a=new THREE.Color(c1),b=new THREE.Color(c2),k=new THREE.Color(),g=()=>Math.random()+Math.random()+Math.random()-1.5;
  for(let i=0;i<n;i++){const r=Math.pow(Math.random(),1.5)*R,ang=(i%3)*2.094+r/R*6+g()*.35;
    p.set([Math.cos(ang)*r+g()*R*.06,g()*R*.05*(1.2-r/R),Math.sin(ang)*r+g()*R*.06],i*3);k.copy(a).lerp(b,r/R);c.set([k.r,k.g,k.b],i*3)}
  const m=pts(p,c,3.2,true);m.position.copy(pos);m.rotation.set(...tilt);gal.push(add(m))}
galaxy(at(320,40,10),110,0xffd9a0,0x6a8cff,[.9,0,.3]);
galaxy(at(420,-120,-18),130,0xffb3d9,0x7a5cff,[.3,0,-.6]);
galaxy(at(380,200,20),100,0xfff2c0,0x4fd8ff,[1.2,0,.2]);

// Planets with procedurally banded textures
function planet(pos,r,hue,ring){const c=document.createElement('canvas');c.width=256;c.height=128;const x=c.getContext('2d');
  for(let y=0;y<128;y+=2){x.fillStyle=`hsl(${hue+Math.random()*30-15},${35+Math.random()*35}%,${30+Math.random()*35}%)`;x.fillRect(0,y,256,2)}
  const m=new THREE.Mesh(new THREE.SphereGeometry(r,48,32),new THREE.MeshStandardMaterial({map:new THREE.CanvasTexture(c),roughness:.9}));
  m.position.copy(pos);spin.push(add(m));
  if(ring){const rg=new THREE.Mesh(new THREE.RingGeometry(r*1.5,r*2.4,64),new THREE.MeshBasicMaterial({color:0xcdb892,side:2,transparent:true,opacity:.55}));rg.position.copy(pos);rg.rotation.x=1.2;add(rg)}}
planet(at(150,25,5),14,30,true);planet(at(110,-70,-8),8,10);planet(at(210,-150,12),18,200);planet(at(260,110,-10),10,270);
add(new THREE.AmbientLight(0x334466,.8));const sun=add(new THREE.DirectionalLight(0xfff0dd,1.6));sun.position.set(1,.5,.4);

// Warp streaks: line segments in camera space, stretched by a shader uniform (uI = intensity)
const NL=700,wp=new Float32Array(NL*6),ws=new Float32Array(NL*2),we=new Float32Array(NL*2);
for(let i=0;i<NL;i++){const a=Math.random()*2*PI,r=3+Math.random()*30,s=Math.random();
  for(let j=0;j<2;j++){wp.set([Math.cos(a)*r,Math.sin(a)*r,0],i*6+j*3);ws[i*2+j]=s;we[i*2+j]=j}}
const wg=new THREE.BufferGeometry();wg.setAttribute('position',new THREE.BufferAttribute(wp,3));wg.setAttribute('aSeed',new THREE.BufferAttribute(ws,1));wg.setAttribute('aEnd',new THREE.BufferAttribute(we,1));
const warpMat=new THREE.ShaderMaterial({uniforms:{uI:{value:0},uT:{value:0}},transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
  vertexShader:`attribute float aSeed,aEnd;uniform float uI,uT;varying float vA;
   void main(){float z=-(300.-mod(aSeed*300.+uT*500.,300.));vA=uI*(1.-aEnd*.8);
   gl_Position=projectionMatrix*modelViewMatrix*vec4(position.xy,z-aEnd*uI*70.,1.);}`,
  fragmentShader:`varying float vA;void main(){gl_FragColor=vec4(.68,.84,1.,vA);}`});
const warp=new THREE.LineSegments(wg,warpMat);warp.frustumCulled=false;warp.visible=false;camera.add(warp);

// Destination marker (positioned from RA/Dec on search)
const target=new THREE.Group(),halo=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex,color:0x7cf3ff,blending:THREE.AdditiveBlending,depthWrite:false})),
  ring=new THREE.Mesh(new THREE.TorusGeometry(13,.25,8,96),new THREE.MeshBasicMaterial({color:0x9ff7ff}));
ring.rotation.x=1.2;halo.scale.set(70,70,1);
target.add(new THREE.Mesh(new THREE.SphereGeometry(5,32,24),new THREE.MeshBasicMaterial({color:0xe8ffff})),halo,ring);target.visible=false;scene.add(target);

/* ============ CAMERA STATE MACHINE: idle -> warp -> orbit -> (warp back) -> idle ============ */
const clock=new THREE.Clock(),tmp=new THREE.Camera(); // THREE.Camera so lookAt() points -Z at the target
let raf=0,mode='idle',yaw=0,pitch0=0,t0=0,base=new THREE.Vector3(),flight=null,orbit=null;

function toIdle(){camera.getWorldDirection(V);yaw=Math.atan2(V.x,-V.z);pitch0=Math.asin(V.y);base.copy(camera.position);t0=clock.elapsedTime;target.visible=false;mode='idle'}

// Cinematic flight: eased position, early slerp toward the target, FOV + streak intensity peak mid-flight
function fly(to,look,dur){return new Promise(done=>{tmp.position.copy(to);tmp.lookAt(look);
  flight={t:0,dur,p0:camera.position.clone(),p1:to.clone(),q0:camera.quaternion.clone(),q1:tmp.quaternion.clone(),done};mode='warp'})}

function frame(){raf=requestAnimationFrame(frame);
  const dt=Math.min(clock.getDelta(),.05),t=clock.elapsedTime;
  spin.forEach(m=>m.rotation.y+=dt*.05);gal.forEach(m=>m.rotation.y+=dt*.01);
  target.children[2].rotation.z+=dt;halo.scale.setScalar(70+Math.sin(t*2)*6);

  if(mode==='idle'){ // slow drift + yaw pan + gentle pitch sway; offsets are 0 at t0 so resuming never jumps
    const s=t-t0;yaw+=dt*.035;
    camera.position.set(base.x+Math.sin(s*.07)*30,base.y+Math.sin(s*.05)*6,base.z+(Math.cos(s*.06)-1)*20);
    camera.lookAt(V.copy(camera.position).add(dirYP(yaw,pitch0+.12*Math.sin(s*.11))));
  }else if(mode==='warp'){
    const f=flight;f.t+=dt;const k=Math.min(f.t/f.dur,1),
      e=k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2,        // easeInOutCubic: slow start, rapid middle, soft landing
      w=Math.pow(Math.sin(PI*k),1.5),                 // 0 -> 1 -> 0 warp intensity
      q=Math.min(k/.45,1);
    camera.position.lerpVectors(f.p0,f.p1,e);
    camera.quaternion.copy(f.q0).slerp(f.q1,q*q*(3-2*q)); // turn toward the destination in the first 45%
    camera.fov=60+75*w;camera.updateProjectionMatrix();
    warpMat.uniforms.uI.value=w;warpMat.uniforms.uT.value+=dt;warp.visible=w>.02;
    if(k>=1){camera.fov=60;camera.updateProjectionMatrix();warp.visible=false;mode='hold';f.done()}
  }else if(mode==='orbit'){
    orbit.ang+=dt*.1;camera.position.copy(orbit.c).add(V.copy(orbit.off).applyAxisAngle(Y,orbit.ang));camera.lookAt(orbit.c);
  }
  renderer.render(scene,camera);drawViewer(t);
}

/* ============ DASHBOARD / LOG ============ */
let busy=false,S=null;
const st=(s,p)=>{$('#xst').textContent=s;$('#xbar').style.width=p+'%'};
function log(m,c=''){const d=document.createElement('div');d.className=c;d.textContent=new Date().toISOString().slice(11,19)+'  '+m;$('#xlog').append(d);$('#xlog').scrollTop=1e9;if(busy)$('#xhud').textContent=m}
function metrics(ra,dec,d){const ts=d.frames.map(f=>+f.t_mjd).filter(Number.isFinite),
  M={'Right ascension':ra.toFixed(4)+'°',Declination:dec.toFixed(4)+'°','Field radius':d.radius_arcmin+'′',Frames:d.imgs.length,'Time span':ts.length?(Math.max(...ts)-Math.min(...ts)).toFixed(1)+' days':'—',Source:d.source,'Changes found':d.detections.length};
  $('#xmetrics').textContent='';Object.entries(M).forEach(([k,v])=>{const e=document.createElement('div'),s=document.createElement('small'),b=document.createElement('b');s.textContent=k;b.textContent=v;e.append(s,b);$('#xmetrics').append(e)})}

/* ============ TIME-SERIES VIEWER + AI / GAME MODES ============ */
const cv=$('#xcv'),g=cv.getContext('2d'),W=512;
function circ(x,y,r,col,dash,lw=2){g.strokeStyle=col;g.lineWidth=lw;g.setLineDash(dash?[6,5]:[]);g.beginPath();g.arc(x*W,y*W,Math.max(r*W,9),0,2*PI);g.stroke()}
function drawViewer(t){if(!S)return;
  if(!S.paused)S.idx=Math.floor(t/S.period)%S.imgs.length; // loops like a GIF
  g.drawImage(S.imgs[S.idx],0,0,W,W);
  if(S.idx!==S.shown){S.shown=S.idx;const f=S.frames[S.idx]||{};$('#xframeInfo').textContent=`Frame ${S.idx+1} of ${S.imgs.length} · ${f.mission} ${f.instrument} ${f.filter} · MJD ${(+f.t_mjd).toFixed(2)}`}
  if(S.mode==='ai')S.det.forEach(d=>{circ(d.x,d.y,d.r*(1+.08*Math.sin(t*4)),'#7cf3ff',true);g.fillStyle='#7cf3ff';g.font='12px sans-serif';g.fillText('#'+d.id,d.x*W+d.r*W+4,d.y*W-d.r*W)});
  else{const now=performance.now();S.tags=S.tags.filter(k=>k.ok||now-k.ts<1200);S.tags.forEach(k=>circ(k.x,k.y,k.r,k.ok?'#7dffb2':'#ff2d46',!k.ok,3))}
}
function score(){$('#xscore').textContent=S.mode==='game'?`Found ${S.det.filter(d=>d.found).length} of ${S.det.length} · ${S.miss} misses`:`AI flagged ${S.det.length} changing objects`}
function setMode(m){S.mode=m;document.querySelectorAll('#xseg button').forEach(b=>b.classList.toggle('on',b.dataset.m===m));
  S.tags=[];S.miss=0;S.det.forEach(d=>d.found=false);
  $('#xhint').textContent=m==='ai'?'AI circles every region that changes between frames.':'AI is hidden. Click objects you think move or change. Pause to compare frames.';score()}
$('#xseg').onclick=e=>{const m=e.target.dataset.m;if(m&&S)setMode(m)};
$('#xpp').onclick=()=>{if(!S)return;S.paused=!S.paused;$('#xpp').textContent=S.paused?'Play':'Pause'};
cv.onclick=e=>{if(!S||S.mode!=='game')return;const b=cv.getBoundingClientRect(),x=(e.clientX-b.left)/b.width,y=(e.clientY-b.top)/b.height,
  hit=S.det.find(d=>!d.found&&Math.hypot(x-d.x,y-d.y)<=d.r*1.5+.02);
  if(hit){hit.found=true;S.tags.push({x:hit.x,y:hit.y,r:hit.r,ok:true});log(`Game: object #${hit.id} found`);if(S.det.every(d=>d.found))log('Game: every object found')}
  else{S.tags.push({x,y,r:.025,ok:false,ts:performance.now()});S.miss++}
  score()};

/* ============ DATA: backend call, with a synthetic fallback so the UI always demos ============ */
const loadImg=u=>new Promise((ok,no)=>{const i=new Image();i.crossOrigin='anonymous';i.onload=()=>ok(i);i.onerror=()=>no(new Error('image failed to load'));i.src=u});
async function fetchData(ra,dec){st('Querying archive',30);log('POST /api/search');
  try{const r=await fetch(API+'/api/search',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ra,dec,radius_arcmin:3,max_frames:8})}),
      d=await r.json().catch(()=>({}));
    if(!r.ok)throw new Error(d.detail||'HTTP '+r.status);
    d.log.forEach(l=>log('server: '+l));st('Loading frames',60);
    d.imgs=await Promise.all(d.frames.map(f=>loadImg(API+f.url)));return d;
  }catch(e){log(`Live data unavailable (${e.message}). Showing synthetic demo frames.`,'warn');return demo()}}
function demo(){const n=8,sp=Array.from({length:90},()=>[Math.random(),Math.random(),Math.random()*1.4+.5]),mv=[{x:.18,y:.3,vx:.07,vy:.03},{x:.8,y:.82,vx:-.05,vy:-.06}],vr={x:.55,y:.4};
  const imgs=[...Array(n)].map((_,i)=>{const c=document.createElement('canvas');c.width=c.height=512;const x=c.getContext('2d'),dot=(a,b,r)=>{x.beginPath();x.arc(a*512,b*512,r,0,7);x.fill()};
    x.fillStyle='#04060c';x.fillRect(0,0,512,512);x.fillStyle='#dbe7ff';
    sp.forEach(s=>dot(...s));mv.forEach(m=>dot(m.x+m.vx*i/7,m.y+m.vy*i/7,3.2));dot(vr.x,vr.y,2+4*Math.abs(Math.sin(i*.9)));return c});
  return{demo:true,source:'Demo (synthetic)',radius_arcmin:3,imgs,frames:imgs.map((_,i)=>({mission:'Demo',instrument:'synthetic',filter:'–',t_mjd:60000+i*3})),
    detections:[...mv.map((m,k)=>({id:k+1,x:m.x+m.vx/2,y:m.y+m.vy/2,r:.1})),{id:3,x:vr.x,y:vr.y,r:.045}]}}

/* ============ SEARCH FLOW ============ */
async function search(){if(busy)return;
  const raS=$('#xra').value,decS=$('#xdec').value,ra=+raS,dec=+decS;
  if(raS===''||decS===''||!(ra>=0&&ra<360&&dec>=-90&&dec<=90))return $('#xerr').textContent='Right ascension must be 0–360° and declination −90 to +90°.';
  $('#xerr').textContent='';busy=true;S=null;$('#xlog').textContent='';
  ROOT.classList.remove('arrived');ROOT.classList.add('flying');
  log(`Target locked: RA ${ra}°, Dec ${dec}°`);st('Warp engaged',15);
  const dir=radec(ra,dec),D=dir.clone().multiplyScalar(900),F=D.clone().addScaledVector(dir,-45); // stop 45 units short
  target.position.copy(D);target.visible=true;
  const [d]=await Promise.all([fetchData(ra,dec),fly(F,D,4.5)]); // data loads while the camera flies
  orbit={c:D.clone(),off:F.clone().sub(D),ang:0};mode='orbit';
  const f=$('#xflash');f.classList.add('on');requestAnimationFrame(()=>requestAnimationFrame(()=>f.classList.remove('on')));
  S={imgs:d.imgs,frames:d.frames,det:d.detections.map(x=>({...x,found:false})),idx:0,shown:-1,paused:false,period:.6,mode:'ai',tags:[],miss:0};
  $('#xpp').textContent='Pause';metrics(ra,dec,d);setMode('ai');
  st(d.demo?'Ready (demo data)':'Ready',100);log(`${d.imgs.length} frames, ${d.detections.length} changing objects`);
  busy=false;$('#xhud').textContent='';ROOT.classList.replace('flying','arrived');
}
$('#xform').onsubmit=e=>{e.preventDefault();search()};
$('#xpresets').onclick=e=>{const b=e.target.closest('button');if(b){$('#xra').value=b.dataset.ra;$('#xdec').value=b.dataset.dec}};
$('#xback').onclick=async()=>{if(busy)return;busy=true;S=null;ROOT.classList.remove('arrived');ROOT.classList.add('flying');
  await fly(new THREE.Vector3(),new THREE.Vector3(0,0,-100),3.2);toIdle();ROOT.classList.remove('flying');busy=false};

function reset(){busy=false;S=null;ROOT.classList.remove('flying','arrived');camera.position.set(0,0,0);camera.fov=60;camera.updateProjectionMatrix();warp.visible=false;toIdle()}
const openX=()=>{cancelAnimationFrame(raf);reset();ROOT.classList.add('open');document.documentElement.style.overflow='hidden';clock.getDelta();frame();setTimeout(()=>$('#xra').focus(),60)},
 closeX=()=>{location.href='index.html'};
$('#xclose').onclick=closeX;
addEventListener('keydown',e=>{if(e.key==='Escape'&&ROOT.classList.contains('open'))closeX()});
toIdle();
openX(); // standalone page: open immediately
})();
