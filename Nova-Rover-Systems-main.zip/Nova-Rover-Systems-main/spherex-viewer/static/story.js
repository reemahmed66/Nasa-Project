const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const rng=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
gsap.registerPlugin(ScrollTrigger);ScrollTrigger.config({ignoreMobileResize:true});

/* smooth scroll */
if(window.Lenis&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
  const lenis=new Lenis({lerp:.09});
  lenis.on('scroll',ScrollTrigger.update);
  gsap.ticker.add(t=>lenis.raf(t*1000));gsap.ticker.lagSmoothing(0);
}

/* parallax star layers */
function tile(n,R,seed){const c=document.createElement('canvas');c.width=c.height=1024;const x=c.getContext('2d'),r=rng(seed);
  for(let i=0;i<n;i++){const col=`hsl(${[200,215,35,340][r()*4|0]} 70% ${82+r()*16}%)`;x.globalAlpha=.4+r()*.6;x.fillStyle=x.shadowColor=col;x.shadowBlur=R*3;x.beginPath();x.arc(16+r()*992,16+r()*992,.5+r()*R,0,7);x.fill()}
  return`url(${c.toDataURL()})`}
const layers=$$('.layer');
layers.forEach((l,i)=>l.style.backgroundImage=tile([140,70,26][i],[1,1.6,2.4][i],i+3));
gsap.ticker.add(()=>{const y=scrollY;layers.forEach(l=>l.style.transform=`translate3d(0,${-(y*l.dataset.s)%1024}px,0)`)});
gsap.to('.nebula',{yPercent:-10,ease:'none',scrollTrigger:{start:0,end:'max',scrub:true}});
gsap.fromTo('#bar',{scaleX:0},{scaleX:1,ease:'none',scrollTrigger:{start:0,end:'max',scrub:.3}});

/* 1. hero */
gsap.from('.hl',{yPercent:115,duration:1.5,ease:'expo.out',stagger:.15,delay:.2});
gsap.from('#hero .fade',{opacity:0,duration:1.4,delay:.9,stagger:.2});
gsap.to('#heroTitle',{scale:.5,opacity:0,y:-60,ease:'none',scrollTrigger:{trigger:'#hero',start:'top top',end:'bottom 15%',scrub:true}});
gsap.to('.cue',{opacity:0,ease:'none',scrollTrigger:{trigger:'#hero',start:'top top',end:'20% top',scrub:true}});

/* 2. time machine: pinned, text enters and exits from the sides */
const ep={v:2023},yr=$('#yr');
const TL=gsap.timeline({defaults:{ease:'none'},scrollTrigger:{trigger:'#time',start:'top top',end:'+=200%',pin:true,scrub:1,anticipatePin:1}});
TL.to(ep,{v:2025,duration:6,onUpdate:()=>yr.textContent=Math.round(ep.v)},0);
$$('.beat').forEach((b,i)=>{const d=+b.dataset.d;
  TL.fromTo(b,{x:d*200,opacity:0,filter:'blur(14px)'},{x:0,opacity:1,filter:'blur(0px)',duration:1,ease:'power2.out'},i*3)
    .to(b,{x:d*200,opacity:0,filter:'blur(14px)',duration:1,ease:'power2.in'},i*3+2)});

/* 4. call to action */
gsap.fromTo('#planet',{yPercent:30},{yPercent:0,ease:'none',scrollTrigger:{trigger:'#cta',start:'top bottom',end:'center center',scrub:true}});
gsap.from('#cta .rise',{yPercent:115,duration:1.3,ease:'expo.out',stagger:.12,scrollTrigger:{trigger:'#cta',start:'top 55%'}});

addEventListener('load',()=>ScrollTrigger.refresh());
document.fonts&&document.fonts.ready.then(()=>ScrollTrigger.refresh());
