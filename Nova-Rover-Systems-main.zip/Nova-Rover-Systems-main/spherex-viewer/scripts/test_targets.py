import ssl
import urllib.request
from astroquery.ipac.irsa import Irsa
from astropy.coordinates import SkyCoord
import astropy.units as u

# 1. إعداد سياق SSL يلغي التحقق لتجنب مشكلة شهادات ويندوز
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

# 2. تحديد مركز البقعة
center = SkyCoord(ra=269.452 * u.deg, dec=4.693 * u.deg, frame='icrs')

print("Querying NASA IRSA Archive...")
images = Irsa.query_sia(pos=(center, 0.5 * u.deg), collection='wise_allwise')

# 3. تحميل الملفات باستخدام السياق الآمن المخصص (SSL Bypass Context)
for i, row in enumerate(images[:4]):
    url = row['access_url']
    filename = f"sky_zone_patch_{i+1}.fits"
    print(f"Downloading {filename} from NASA...")
    
    # استخدام urlopen مع الـ context بدلاً من urlretrieve العادية
    try:
        with urllib.request.urlopen(url, context=ctx, timeout=30) as response, open(filename, 'wb') as out_file:
            out_file.write(response.read())
        print(f"-> Successfully saved {filename}")
    except Exception as e:
        print(f"-> Failed to download {filename}: {e}")

print("Done! Local Sky Patch process completed.")